import numpy as np

A = np.array([[2, 5], [1, 3]])
print(np.linalg.inv(A))