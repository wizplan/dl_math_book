a = set([2, 4, 5])   # 집합 A 생성
b = set([3, 4, 6])   # 집합 B 생성

print(a)             # 집합 A 출력
print(a & b)         # 교집합 출력
print(a - b)         # 차집합 출력
print(a | b)         # 합집합 출력