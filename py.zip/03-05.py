import numpy as np

X = np.array([[1, 2, 3], [3, 4, 5]])
Y = np.array([[3, 4, 5], [4, 5, 6]])

print(X + Y)
print(X - Y)