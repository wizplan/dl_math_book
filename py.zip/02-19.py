import random

print(random.random())
print(random.random())
print(random.random())