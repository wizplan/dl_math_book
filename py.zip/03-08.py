import numpy as np

A = np.array([[2, 5], [1, 3]])
print(np.linalg.det(A))

B = np.array([[1, 4, 2], [3, -1, -2], [-3, 1, 3]])
print(np.linalg.det(B))