def func(x):
    return 2 * x + 1

print(func(-2))
print(func(1))