import numpy as np

data = [70, 91, 69, 78, 82]
avg = np.mean(data)

print(avg)