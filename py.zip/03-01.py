import numpy as np

a = np.array([2, 1])
print(a)

b = np.array([3, 2, 1])
print(b)

A = np.array([[2, 4, 1], [6, 3, 5]])
print(A)