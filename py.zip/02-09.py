b = [[0] * 3] * 4

print(b)