sum_value = 0

for i in range(1, 101, 3):
    sum_value += i

print(sum_value)