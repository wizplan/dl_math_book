data = [70, 91, 69, 78, 82]
total = sum(data)         # 데이터의 합 계산
print(total)

avg = total / len(data)   # 평균 계산
print(avg)