a = [i for i in range(1, 101, 3)]
total = sum(a)

print(total)