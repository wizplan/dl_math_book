sum_value = 0

for i in range(1, 8):   # range 함수는 반복 실행에 마지막 인자를 포함하지 않음
    sum_value += i

print(sum_value)