import numpy as np

a = [173, 181, 168, 175, 179]
b = [1.73, 1.81, 1.68, 1.75, 1.79]

print(np.var(a))
print(np.var(b))