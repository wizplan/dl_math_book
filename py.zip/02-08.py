a = [0] * 7

print(a)