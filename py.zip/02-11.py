c = [[0 for i in range(3)] for j in range(4)]
c[1][2] = 5

print(c)