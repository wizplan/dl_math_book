import numpy as np

a = [72, 61, 91, 31, 45]

print(np.var(a))   # 분산 출력
print(np.std(a))   # 표준편차 출력