month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]

for i in range(12):
    print(i + 1, "월", month[i])