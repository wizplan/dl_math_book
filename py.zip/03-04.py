import numpy as np

a = np.array([3, 2])
b = np.array([1, 4])

print(a.dot(b))   # 벡터 a와 b의 내적

c = np.array([2, 1])
d = np.array([-1, 2])

print(c.dot(d))   # 벡터 c와 d의 내적